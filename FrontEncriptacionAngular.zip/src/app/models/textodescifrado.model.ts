import { Deserializable } from "./deserializable.model";

export class TextoDescifrado implements Deserializable {
    textoDescifrado: string = "";
    metodo: string = "";

    deserialize(input: any) {
        Object.assign(this, input);
        return this;
    }
}
