import { Deserializable } from "./deserializable.model";

export class TextoDesencriptar implements Deserializable {
    textoCifrado: string = "";
    metodo: string = "";

    deserialize(input: any) {
        Object.assign(this, input);
        return this;
    }
}
