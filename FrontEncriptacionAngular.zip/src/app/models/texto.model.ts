import { Deserializable } from "./deserializable.model";

export class Texto implements Deserializable {
    textoNormal: string = "";
    metodo: string = "";

    deserialize(input: any) {
        Object.assign(this, input);
        return this;
    }
}
