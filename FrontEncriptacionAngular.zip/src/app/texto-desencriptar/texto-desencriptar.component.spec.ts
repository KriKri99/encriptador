/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { TextoDesencriptarComponent } from './texto-desencriptar.component';

describe('TextoDesencriptarComponent', () => {
  let component: TextoDesencriptarComponent;
  let fixture: ComponentFixture<TextoDesencriptarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TextoDesencriptarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TextoDesencriptarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
