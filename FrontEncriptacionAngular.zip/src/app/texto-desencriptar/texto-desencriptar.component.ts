import { TextoDesencriptar } from './../models/textoDesencriptar.model';
import { Component, Injectable, Input, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Texto } from '../models/texto.model';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { TextoDescifrado } from '../models/textodescifrado.model';
import swal from 'sweetalert';

@Component({
  selector: 'app-texto-desencriptar',
  templateUrl: './texto-desencriptar.component.html',
  styleUrls: ['./texto-desencriptar.component.css']
})
@Injectable({ providedIn: 'root' })
export class TextoDesencriptarComponent implements OnInit {
  //private readonly API_URL = 'http://localhost:9090/';
  private readonly API_URL = 'https://encriptacion-sess.herokuapp.com/';
  public textoCifrado: string = "";
  public textoDescifrado: string = "";
  texto: Texto = new Texto();
  textoDesencripar = new TextoDesencriptar();
  resultDescifrado = new TextoDescifrado();

  public form2 = new FormGroup({
    textoCifrado: new FormControl(''),
    metodo2: new FormControl('BASE64'),
  });
  constructor(private HttpClient: HttpClient) { }

  ngOnInit() {
    console.info("Init: metodo-> " + localStorage.getItem('metodo'));
    this.form2.patchValue({ metodo2: localStorage.getItem('metodo') })
  }

  onSubmitDeCifrar() {
    console.info(this.form2.value);
    this.textoDesencripar.textoCifrado = '' + this.form2.value.textoCifrado;
    if (this.form2.value.metodo2 != null) {
      this.textoDesencripar.metodo = '' + this.form2.value.metodo2;
    } else {
      this.textoDesencripar.metodo = '' + localStorage.getItem('metodo');
    }
    if (this.textoDesencripar.textoCifrado == null || this.textoDesencripar.textoCifrado == '') {
      swal("Error", "Ingrese alguna palabra o texto!", "error")
    } else {
      let headers = new HttpHeaders();
      headers = headers.set('Content-Type', 'application/json; charset=utf-8');
      let body = JSON.stringify(this.textoDesencripar);
      this.HttpClient.post<TextoDescifrado>(this.API_URL + 'v1/desencriptar', body, {
        headers: new HttpHeaders({ 'Content-Type': 'application/json; charset=utf-8' })
      }).subscribe(Response => {
        swal("Mensaje", "Texto Desencriptado con exitó!", "success")
        this.resultDescifrado = Response;
        this.textoDescifrado = this.resultDescifrado.textoDescifrado;
        console.log(Response)
      },
      error =>{
        console.log('oops', error);
        swal("Error", "Ocurrió un error en desencriptar su texto, verifique el metodo e intente de nuevo!", "error");
      });
      console.info(this.textoDescifrado)
    }
  }

  getMetodo() {
    console.info(localStorage.getItem('metodo'));
    return localStorage.getItem('metodo');
  }

  getCleanDescifrar() {
    this.textoDesencripar.textoCifrado = "";
  }

  changeSelect(){
    console.info('Update Select...');
    this.form2.patchValue({ metodo2: localStorage.getItem('metodo') });
  }

}
