import { TextoCifrado } from './../models/textocifrado.model';
import { Component, EventEmitter, Injectable, Input, OnInit, Output } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Texto } from '../models/texto.model';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import swal from 'sweetalert';

@Component({
  selector: 'app-texto',
  templateUrl: './texto.component.html',
  styleUrls: ['./texto.component.css']
})

@Injectable(
  { providedIn: 'root' }
)
export class TextoComponent implements OnInit {

  //private readonly API_URL = 'http://localhost:9090/';
  private readonly API_URL = 'https://encriptacion-sess.herokuapp.com/';

  public textoCifrado: string = "";
  public textoDescifrado: string = "";
  texto: Texto = new Texto();
  resultCifrado = new TextoCifrado();

  public form = new FormGroup({
    textoNormal: new FormControl(''),
    metodo: new FormControl('BASE64'),
  });
  constructor(private HttpClient: HttpClient) { }

  ngOnInit(): void {
  }

  onSubmitCifrar() {
    console.info(this.form.value);
    this.texto.textoNormal = '' + this.form.value.textoNormal;
    this.texto.metodo = '' + this.form.value.metodo;
    if (this.texto.textoNormal == null || this.texto.textoNormal == '') {
      swal("Error", "Ingrese alguna palabra o texto!", "error")
    } else {
      let headers = new HttpHeaders();
      headers = headers.set('Content-Type', 'application/json; charset=utf-8');
      let body = JSON.stringify(this.texto);
      this.HttpClient.post<TextoCifrado>(this.API_URL + 'v1/encriptar', body, {
        headers: new HttpHeaders({ 'Content-Type': 'application/json; charset=utf-8' })
      }).subscribe(Response => {
        swal("Mensaje", "Texto encriptado con exitó!", "success")
        this.resultCifrado = Response;
        this.textoCifrado = this.resultCifrado.textoCifrado;
        console.log(Response);
        localStorage.setItem('metodo', this.texto.metodo);
      },
      error =>{
        console.log('oops', error);
        swal("Error", "Ocurrió un error en encriptar su texto, intente de nuevo!", "error");
      });
      console.info(this.resultCifrado)
    }
  }

  getCleanCifrar() {
    this.texto.textoNormal = "";
  }
}
