import { FormControl, FormGroup } from '@angular/forms';
import { Component, Injectable, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpEventType, HttpHeaders, HttpResponse } from '@angular/common/http';
import swal from 'sweetalert';

@Component({
  selector: 'app-archivo',
  templateUrl: './archivo.component.html',
  styleUrls: ['./archivo.component.css']
})
@Injectable({
  providedIn: 'root'
})
export class ArchivoComponent implements OnInit {
  //private readonly API_URL = 'http://localhost:9090/';
  private readonly API_URL = 'https://encriptacion-sess.herokuapp.com/';
  selectedFileEncrypt?: FileList;
  selectedFileDecrypt?: FileList;
  btnEncriptar: boolean = false;
  btnDesencriptar: boolean = false;
  metodo?: string;
  currentFile?: File;
  progress1 = 0;
  progress2 = 0;
  message = '';
  fileInfos?: Observable<any>;
  public formD = new FormGroup({
    metodo2: new FormControl('BASE64'),
  });
  public formE = new FormGroup({
    metodo1: new FormControl('BASE64'),
  });

  constructor(private HttpClient: HttpClient) { }

  ngOnInit(): void {
    this.metodo = "BASE64";
  }

  onSubmitCifrarArchivo() {
    this.progress1 = 0;
    if (this.selectedFileEncrypt == null) {
      swal("Error", "Ingrese un archivo", "error")
    } else {
      const file: File | null = this.selectedFileEncrypt.item(0);

      if (file) {
        const formData: FormData = new FormData();
        this.currentFile = file;
        formData.append('archivo', this.currentFile);
        formData.append('metodo', '' + this.metodo);
        this.btnEncriptar = false;
        console.log(formData);
        this.HttpClient.post(this.API_URL + 'v1/encriptar/archivo', formData, {
          responseType: "arraybuffer", headers: new HttpHeaders()
        }).subscribe(response => {
          this.progress1 = 100;
          this.btnEncriptar = true;
          swal("Mensaje", "Archivo Encriptado con exitó!", "success");
          console.log(file.type);
          var filename = file.name.split(".");
          var filenameOut = filename[0] + "_" + this.metodo + "." + filename[1];
          console.log(filenameOut);
          console.log(response);
          //this.downLoadFile(response, file.type)
          this.blobToFile(response, file.type, filenameOut);
        },
        error =>{
          console.log('oops', error);
          swal("Error", "Ocurrió un error en encriptar su archivo, intente de nuevo!", "error");
        });

      }
    }
  }

  onSubmitDescifrarArchivo() {
    this.progress2 = 0;
    if (this.selectedFileDecrypt == null) {
      swal("Error", "Ingrese un archivo!", "error")
    } else {
      const file: File | null = this.selectedFileDecrypt.item(0);

      if (file) {
        const formData: FormData = new FormData();
        this.currentFile = file;
        formData.append('archivo', this.currentFile);
        formData.append('metodo', '' + this.metodo);
        this.btnDesencriptar = false;
        console.log(formData);
        this.HttpClient.post(this.API_URL + 'v1/desencriptar/archivo', formData, {
          responseType: "arraybuffer", headers: new HttpHeaders()
        }).subscribe(response => {
          this.progress2 = 100;
          this.btnDesencriptar = true;
          swal("Mensaje", "Archivo Desencriptado con exitó!", "success");
          console.log(file.type);
          var filename = file.name.split(".");
          var filenameOut = filename[0] + "_" + this.metodo + "." + filename[1];
          console.log(filenameOut);
          //this.downLoadFile(response, file.type);
          this.blobToFile(response, file.type, file.name);
        },
        error =>{
          console.log('oops', error);
          swal("Error", "Ocurrió un error en desencriptar su archivo, verifique el metodo e intente de nuevo!", "error");
        });

      }
    }
  }

  selectFileE(event: any): void {
    this.selectedFileEncrypt = event.target.files;
    this.btnEncriptar = true;
  }

  selectFileD(event: any): void {
    this.selectedFileDecrypt = event.target.files;
    this.btnDesencriptar = true;
  }

  selectMetodo(event: any): void {
    this.metodo = event.target.value;
    this.formD.patchValue({ metodo2: this.metodo })
    console.log(this.metodo);
  }


  /**
    * Method is use to download file.
    * @param data - Array Buffer data
    * @param type - type of the document.
    */
  downLoadFile(data: any, type: string) {
    let blob = new Blob([data], { type: type });
    let url = window.URL.createObjectURL(blob);
    let pwa = window.open(url);
    if (!pwa || pwa.closed || typeof pwa.closed == 'undefined') {
      swal('Advertencia', 'Por favor desactive el bloqueo de ventanas secundarias e intente de nuevo.', 'info');
    }
  }

  /**
   * Method is use to download file.
   * @param data - Array Buffer data
   * @param type - type of the file.
   * @param fileName - name of the file.
   */
  blobToFile(data: any, type: string, fileName: string) {
    const a = document.createElement('a');
    document.body.appendChild(a);
    a.style.display = 'none';
    const blob = new Blob([data], { type: type });
    const url = window.URL.createObjectURL(blob);
    a.href = url; a.download = fileName; a.click();
    window.URL.revokeObjectURL(url);
  }
}
