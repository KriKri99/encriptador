import { Texto } from './models/texto.model';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { TextoCifrado } from './models/textocifrado.model';

@Injectable({
    providedIn: "root"
})
export class DataServices {

    public resultText: any;
    constructor(private HttpClient: HttpClient) {

    }


    public encriptarTexto(texto: Texto): Observable<TextoCifrado> {
        let headers = new HttpHeaders();
        headers = headers.set('Content-Type', 'application/json; charset=utf-8');
        let body = JSON.stringify(texto);
        return this.HttpClient.post<TextoCifrado>('http://localhost:9090/v1/encriptar', body, {
            headers: new HttpHeaders({ 'Content-Type': 'application/json; charset=utf-8' })
        })
    }
}
