import { TextoDesencriptarComponent } from './texto-desencriptar/texto-desencriptar.component';
import { Component, Injectable } from '@angular/core';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
@Injectable()
export class AppComponent {
  title = 'Encriptacion-SESS';
  activeTab: string = 'textoe';

  constructor(private textoD: TextoDesencriptarComponent) { }

  search(activeTab: string) {
    this.activeTab = activeTab;
  }

  result(activeTab: string) {
    this.activeTab = activeTab;
  }
}
